"use client";

import React, { createContext, useContext, useState, useEffect } from 'react';

export interface WSAlert {
  id: string;
  primaryObject: string;
  primaryNorad: string;
  secondaryObject: string;
  secondaryNorad: string;
  missDistance: number;
  timeToImpact: number;
  probability: number;
  urgency: "CRITICAL" | "HIGH";
}

interface ConjunctionContextType {
  alerts: WSAlert[];
  isConnected: boolean;
}

const ConjunctionContext = createContext<ConjunctionContextType>({
  alerts: [],
  isConnected: false
});

export const useConjunctions = () => useContext(ConjunctionContext);

export function ConjunctionProvider({ children }: { children: React.ReactNode }) {
  const [alerts, setAlerts] = useState<WSAlert[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    let ws: WebSocket;
    let reconnectTimer: NodeJS.Timeout;

    const connect = () => {
      ws = new WebSocket("ws://localhost:8000/ws/conjunctions");

      ws.onopen = () => {
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.status === "success" && Array.isArray(data.alerts)) {
            setAlerts(data.alerts);
            
            // Post critical alerts to database for historical logging
            data.alerts.forEach((alert: WSAlert) => {
              if (alert.urgency === "CRITICAL") {
                fetch('/api/alerts', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(alert)
                }).catch(err => console.error("Failed to log alert:", err));
              }
            });
          }
        } catch (e) {
          console.error("Error parsing websocket message:", e);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        // Attempt to reconnect after 3 seconds
        reconnectTimer = setTimeout(connect, 3000);
      };
      
      ws.onerror = () => {
        ws.close();
      };
    };

    connect();

    return () => {
      clearTimeout(reconnectTimer);
      if (ws) ws.close();
    };
  }, []);

  return (
    <ConjunctionContext.Provider value={{ alerts, isConnected }}>
      {children}
    </ConjunctionContext.Provider>
  );
}
