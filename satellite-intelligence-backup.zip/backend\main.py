from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from skyfield.api import EarthSatellite, load
import requests
import datetime
import math
import itertools
import asyncio
import time
import numpy as np

app = FastAPI(title="Aerospace Intelligence Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ts = load.timescale()

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

TLE_CACHE = []
LAST_FETCH = 0

def fetch_tle_data():
    global TLE_CACHE, LAST_FETCH
    if time.time() - LAST_FETCH < 3600 and TLE_CACHE:
        return TLE_CACHE

    url = "https://celestrak.org/NORAD/elements/gp.php?FORMAT=tle&GROUP=stations"
    try:
        r = requests.get(url, timeout=10)
        lines = r.text.strip().split('\n')
        satellites = []
        for i in range(0, len(lines)-2, 3):
            name = lines[i].strip()
            line1 = lines[i+1].strip()
            line2 = lines[i+2].strip()
            satellites.append({
                "name": name,
                "line1": line1,
                "line2": line2
            })
        TLE_CACHE = satellites
        LAST_FETCH = time.time()
        return satellites
    except Exception as e:
        print(f"Error fetching TLEs: {e}")
        return TLE_CACHE

def calculate_conjunctions():
    raw_sats = fetch_tle_data()
    # Scale up to 500 satellites instead of 50
    demo_sats = raw_sats[:500]
    
    skyfield_sats = []
    valid_names = []
    for s in demo_sats:
        try:
            sat = EarthSatellite(s["line1"], s["line2"], s["name"], ts)
            skyfield_sats.append(sat)
            valid_names.append(s["name"])
        except:
            pass

    t = ts.now()
    alerts = []
    
    # Pre-calculate all positions (Nx3 matrix)
    positions = []
    for sat in skyfield_sats:
        positions.append(sat.at(t).position.km)
        
    positions = np.array(positions)
    
    # Vectorized distance calculation
    # We want to find pairs where distance < 5000
    if len(positions) > 1:
        # Create a boolean mask of upper triangle to avoid duplicates and self-comparisons
        n = len(positions)
        # Using broadcasting to get pairwise differences: pos[:, None, :] - pos[None, :, :]
        # This creates an NxNx3 matrix. Memory for 500x500 is very small (500*500*3*8 bytes ~ 6MB)
        diff = positions[:, np.newaxis, :] - positions[np.newaxis, :, :]
        dist_sq = np.sum(diff**2, axis=-1)
        
        # We only care about upper triangle (j > i)
        i_idx, j_idx = np.triu_indices(n, k=1)
        distances_sq_triu = dist_sq[i_idx, j_idx]
        
        # Filter where distance squared < 5000^2
        close_pairs = np.where(distances_sq_triu < 25000000)[0]
        
        for idx in close_pairs:
            i = i_idx[idx]
            j = j_idx[idx]
            dist = math.sqrt(distances_sq_triu[idx])
            sat1 = skyfield_sats[i]
            sat2 = skyfield_sats[j]
            
            alerts.append({
                "id": f"C-{sat1.model.satnum}-{sat2.model.satnum}",
                "primaryObject": sat1.name,
                "primaryNorad": str(sat1.model.satnum),
                "secondaryObject": sat2.name,
                "secondaryNorad": str(sat2.model.satnum),
                "missDistance": round(dist * 1000),
                "timeToImpact": int(dist / 7.0),
                "probability": round((5000 - dist) / 500, 2),
                "urgency": "CRITICAL" if dist < 1000 else "HIGH"
            })

    alerts.sort(key=lambda x: x["missDistance"])
    return {"status": "success", "count": len(alerts), "alerts": alerts[:10]}

# Legacy REST endpoint
@app.get("/api/conjunctions")
def get_conjunctions():
    return calculate_conjunctions()

# New WebSocket endpoint
@app.websocket("/ws/conjunctions")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        # Send initial data instantly
        await websocket.send_json(calculate_conjunctions())
        
        while True:
            # Keep connection alive
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_text("pong")
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# Background task to broadcast to all clients every 5 seconds
async def physics_broadcaster():
    while True:
        await asyncio.sleep(5)
        if manager.active_connections:
            data = calculate_conjunctions()
            await manager.broadcast(data)

@app.on_event("startup")
async def startup_event():
    asyncio.create_task(physics_broadcaster())
