import { NextResponse } from 'next/server';

export const revalidate = 3600; // Cache for 1 hour

interface RawSatellite {
  name: string;
  noradId: string;
  line1: string;
  line2: string;
  type: string;
}

const CELESTRAK_BASE = 'https://celestrak.org/NORAD/elements/gp.php?FORMAT=tle&GROUP=';

async function fetchGroup(group: string, type: string): Promise<RawSatellite[]> {
  try {
    const response = await fetch(`${CELESTRAK_BASE}${group}`, { next: { revalidate: 3600 } });
    if (!response.ok) throw new Error(`Failed to fetch ${group}`);
    
    const text = await response.text();
    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    
    const satellites: RawSatellite[] = [];
    // TLEs come in 3 lines: Name, Line1, Line2
    for (let i = 0; i < lines.length - 2; i += 3) {
      const name = lines[i];
      const line1 = lines[i+1];
      const line2 = lines[i+2];
      
      // Extract NORAD ID from Line 2 (chars 2-7)
      const noradId = line2.substring(2, 7).trim();
      
      satellites.push({
        name,
        noradId,
        line1,
        line2,
        type
      });
    }
    return satellites;
  } catch (error) {
    console.error(`Error fetching ${group}:`, error);
    return [];
  }
}

export async function GET() {
  try {
    // Fetch a curated high-interest list to keep performance high
    const [stations, weather, gnss, active, iridiumDebris, fengyunDebris] = await Promise.all([
      fetchGroup('stations', 'Space Station'),
      fetchGroup('weather', 'Weather'),
      fetchGroup('gnss', 'Navigation'),
      // Fetch a small subset of active to simulate larger catalog
      fetchGroup('resource', 'Earth Obs'),
      // Debris Catalogs
      fetchGroup('iridium-33-debris', 'Debris'),
      fetchGroup('1999-025', 'Debris')
    ]);

    const allSatellites = [...stations, ...weather, ...gnss, ...active, ...iridiumDebris, ...fengyunDebris];
    
    // Deduplicate by NORAD ID just in case
    const uniqueMap = new Map<string, RawSatellite>();
    allSatellites.forEach(sat => {
      uniqueMap.set(sat.noradId, sat);
    });

    const catalog = Array.from(uniqueMap.values());

    return NextResponse.json({
      status: 'nominal',
      timestamp: new Date().toISOString(),
      count: catalog.length,
      data: catalog
    });
  } catch (error) {
    return NextResponse.json({
      status: 'error',
      message: 'Failed to retrieve satellite catalog'
    }, { status: 500 });
  }
}
