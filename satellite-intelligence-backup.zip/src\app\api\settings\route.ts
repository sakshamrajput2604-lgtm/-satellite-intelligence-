import { NextResponse } from 'next/server';
import db from '@/lib/db';
import { getAuthenticatedUser } from '@/lib/auth';

export async function GET() {
  const user = await getAuthenticatedUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const stmt = db.prepare('SELECT collision_threshold, lookahead_hours FROM settings WHERE user_id = ?');
    const settings = stmt.get(user.id);

    return NextResponse.json({ settings });
  } catch (err) {
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const user = await getAuthenticatedUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  try {
    const { collision_threshold, lookahead_hours } = await req.json();

    const stmt = db.prepare(`
      UPDATE settings 
      SET collision_threshold = ?, lookahead_hours = ? 
      WHERE user_id = ?
    `);
    
    stmt.run(collision_threshold, lookahead_hours, user.id);

    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  }
}
