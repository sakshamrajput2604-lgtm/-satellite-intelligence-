"use client";

import React, { useState, useEffect } from "react";
import { Settings, Save, Server, Shield, Monitor } from "lucide-react";

export default function SettingsPage() {
  const [saved, setSaved] = useState(false);
  const [threshold, setThreshold] = useState<number>(2.5);
  const [lookahead, setLookahead] = useState<number>(72);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetch('/api/settings');
        if (res.ok) {
          const data = await res.json();
          if (data.settings) {
            setThreshold(data.settings.collision_threshold);
            setLookahead(data.settings.lookahead_hours);
          }
        }
      } catch (err) {
        console.error("Failed to load settings", err);
      } finally {
        setLoading(false);
      }
    }
    loadSettings();
  }, []);

  const handleSave = async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          collision_threshold: threshold,
          lookahead_hours: lookahead
        })
      });
      if (res.ok) {
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } catch (err) {
      console.error("Failed to save settings", err);
    }
  };

  if (loading) return <div className="p-8 text-cyan-400 font-mono tracking-widest uppercase animate-pulse">Loading Configuration...</div>;

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col gap-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-slate-700/50 pb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Settings className="text-slate-400 w-8 h-8" />
            System Configuration
          </h1>
          <p className="text-slate-400 mt-2 text-sm">
            Manage data feed origins, physics engine parameters, and UI preferences.
          </p>
        </div>
        
        <button 
          onClick={handleSave}
          className="flex items-center gap-2 px-6 py-2 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-sm uppercase tracking-widest rounded transition-colors"
        >
          {saved ? 'Saved' : 'Save Changes'}
          <Save size={16} />
        </button>
      </div>

      <div className="space-y-6 pb-12">
        {/* API Settings */}
        <div className="cyber-panel p-6 border-slate-700/30">
          <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Server size={16} /> Telemetry Data Feeds
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">Space-Track API Key</label>
              <input type="password" placeholder="••••••••••••••••" className="w-full bg-black border border-slate-700 rounded p-3 text-white font-mono outline-none focus:border-cyan-500 transition-colors" />
            </div>
            
            <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded border border-slate-800">
              <div>
                <div className="text-sm text-white font-bold">Use CelesTrak Public Feed</div>
                <div className="text-xs text-slate-500">Fallback to public unauthenticated TLE data.</div>
              </div>
              <div className="w-12 h-6 bg-cyan-500/20 border border-cyan-500 rounded-full relative cursor-pointer">
                <div className="absolute top-0.5 right-0.5 w-4 h-4 bg-cyan-400 rounded-full" />
              </div>
            </div>
          </div>
        </div>

        {/* Engine Settings */}
        <div className="cyber-panel p-6 border-slate-700/30">
          <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Shield size={16} /> Physics & Collision Engine
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">Collision Probability Threshold (%)</label>
              <input 
                type="number" 
                value={threshold} 
                onChange={(e) => setThreshold(parseFloat(e.target.value))}
                step={0.1} 
                className="w-full bg-black border border-slate-700 rounded p-3 text-white font-mono outline-none focus:border-cyan-500 transition-colors" 
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-slate-400 uppercase tracking-widest mb-2">Simulation Lookahead (Hours)</label>
              <input 
                type="number" 
                value={lookahead} 
                onChange={(e) => setLookahead(parseInt(e.target.value))}
                className="w-full bg-black border border-slate-700 rounded p-3 text-white font-mono outline-none focus:border-cyan-500 transition-colors" 
              />
            </div>
          </div>
        </div>

        {/* UI Settings */}
        <div className="cyber-panel p-6 border-slate-700/30">
          <h2 className="text-sm font-bold text-cyan-400 uppercase tracking-widest mb-6 flex items-center gap-2">
            <Monitor size={16} /> Interface Preferences
          </h2>
          
          <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded border border-slate-800">
            <div>
              <div className="text-sm text-white font-bold">Cinematic Scanlines</div>
              <div className="text-xs text-slate-500">Enable CRT radar sweep effects.</div>
            </div>
            <div className="w-12 h-6 bg-cyan-500/20 border border-cyan-500 rounded-full relative cursor-pointer">
              <div className="absolute top-0.5 right-0.5 w-4 h-4 bg-cyan-400 rounded-full" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
