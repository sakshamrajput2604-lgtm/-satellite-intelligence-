import { NextResponse } from 'next/server';
import db from '@/lib/db';
import bcrypt from 'bcryptjs';
import { SignJWT } from 'jose';

// Secret key for JWT signing. In production this MUST be an environment variable!
const JWT_SECRET = new TextEncoder().encode('SUPER_SECRET_AEROSPACE_ENCRYPTION_KEY_2026');

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password required' }, { status: 400 });
    }

    // 1. Find user in SQLite Database
    const stmt = db.prepare('SELECT * FROM users WHERE email = ?');
    const user = stmt.get(email) as any;

    if (!user) {
      return NextResponse.json({ error: 'Access Denied: Invalid Credentials' }, { status: 401 });
    }

    // 2. Cryptographically verify the password
    const passwordMatch = bcrypt.compareSync(password, user.password);
    
    if (!passwordMatch) {
      return NextResponse.json({ error: 'Access Denied: Invalid Credentials' }, { status: 401 });
    }

    // 3. Generate mathematically signed JSON Web Token (JWT)
    const token = await new SignJWT({ 
        id: user.id, 
        email: user.email, 
        clearance: user.clearance_level,
        role: user.role
      })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('8h') // Token expires in 8 hours
      .sign(JWT_SECRET);

    // 4. Return success and instruct browser to set HTTP-only cookie
    const response = NextResponse.json({ success: true }, { status: 200 });
    
    response.cookies.set({
      name: 'auth_token',
      value: token,
      httpOnly: true, // Prevents JavaScript XSS attacks from stealing the token
      path: '/',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 60 * 60 * 8 // 8 hours
    });

    return response;

  } catch (error) {
    console.error("Login API Error:", error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
