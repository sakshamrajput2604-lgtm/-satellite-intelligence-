import { NextResponse } from 'next/server';
import db from '@/lib/db';

export async function GET() {
  try {
    const stmt = db.prepare('SELECT * FROM alerts ORDER BY timestamp DESC LIMIT 50');
    const alerts = stmt.all();
    return NextResponse.json({ success: true, alerts });
  } catch (error) {
    console.error("Error fetching alerts:", error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { id, primaryObject, primaryNorad, secondaryObject, secondaryNorad, missDistance, timeToImpact, probability } = data;

    if (!id || !primaryObject || !secondaryObject) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const insert = db.prepare(`
      INSERT OR IGNORE INTO alerts 
      (id, primaryObject, primaryNorad, secondaryObject, secondaryNorad, missDistance, timeToImpact, probability) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insert.run(id, primaryObject, primaryNorad, secondaryObject, secondaryNorad, missDistance, timeToImpact, probability);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error saving alert:", error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
