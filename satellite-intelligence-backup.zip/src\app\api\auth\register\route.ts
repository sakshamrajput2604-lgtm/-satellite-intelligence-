import { NextResponse } from 'next/server';
import db from '@/lib/db';
import bcrypt from 'bcryptjs';
import { getAuthenticatedUser } from '@/lib/auth';

export async function POST(req: Request) {
  try {
    // 1. Authenticate the requester
    const currentUser = await getAuthenticatedUser();
    
    if (!currentUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Verify Clearance Level
    // Only Level 5 Commanders can create new accounts
    if (currentUser.clearance < 5) {
      return NextResponse.json({ error: 'Insufficient Clearance Level' }, { status: 403 });
    }

    const { email, password, role, clearance_level } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: 'Email and password required' }, { status: 400 });
    }

    // 3. Cryptographically hash the new user's password
    const salt = bcrypt.genSaltSync(10);
    const hashedPassword = bcrypt.hashSync(password, salt);

    // 4. Insert into the database
    const insert = db.prepare('INSERT INTO users (email, password, clearance_level, role) VALUES (?, ?, ?, ?)');
    const info = insert.run(email, hashedPassword, clearance_level || 1, role || 'ANALYST');
    
    // 5. Create a default settings row for the new user
    const insertSettings = db.prepare('INSERT INTO settings (user_id) VALUES (?)');
    insertSettings.run(info.lastInsertRowid);

    return NextResponse.json({ success: true, message: 'Officer registered successfully.' }, { status: 201 });

  } catch (error: any) {
    if (error.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return NextResponse.json({ error: 'An officer with this email already exists' }, { status: 409 });
    }
    console.error("Registration Error:", error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
