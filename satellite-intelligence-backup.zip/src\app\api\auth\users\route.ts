import { NextResponse } from 'next/server';
import db from '@/lib/db';
import { getAuthenticatedUser } from '@/lib/auth';

export async function GET() {
  try {
    const currentUser = await getAuthenticatedUser();
    
    if (!currentUser || currentUser.clearance < 5) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const stmt = db.prepare('SELECT id, email, clearance_level, role FROM users');
    const users = stmt.all();

    return NextResponse.json({ users });
  } catch (error) {
    return NextResponse.json({ error: 'Database error' }, { status: 500 });
  }
}
